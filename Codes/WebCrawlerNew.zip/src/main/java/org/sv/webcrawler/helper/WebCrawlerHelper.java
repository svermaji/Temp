package org.sv.webcrawler.helper;

import org.jsoup.nodes.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.sv.webcrawler.DocDownLoader;

import java.util.List;

/**
 * A simple web crawler that will crawl through a website
 * considering root url provided
 */
public enum WebCrawlerHelper {

    INSTANCE;

    private Logger logger;
    private DocDownLoader docDownLoader;
    private boolean debug;

    WebCrawlerHelper() {
        logger = LoggerFactory.getLogger(this.getClass());
        debug = logger.isDebugEnabled();
        docDownLoader = new DocDownLoader();
    }

    public List<String> getPageLinks(String url) {
        if (debug) {
            logger.debug("Retrieving page links for url [" + url + "]");
        }
        Document htmlDoc = docDownLoader.download(url);
        return docDownLoader.makeAbsHrefLinks(docDownLoader.getHrefLinks(htmlDoc));
    }
}