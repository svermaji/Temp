package org.sv.webcrawler.util;

import org.apache.commons.lang3.StringUtils;

public class Utils {

    public static final String DOUBLE_QUOTE = "\"";
    public static final String FWD_SLASH = "/";
    public static final String SPACE = " ";
    public static final String COMMA = ",";
    public static final String COMMA_SPACE = COMMA + SPACE;
    public static final String HTTP = "http://";
    public static final String HTTPS = "https://";
    public static final String WWW = "www";
    public static final String HREF = "href";
    public static final String SRC = "src";

    /**
     * return true if param has non-null value
     * This way even if we need to make any specific change
     * we can achieve from this central place
     *
     * @param item string to be checked
     * @return boolean status of operation
     */
    public static boolean hasValue(String item) {
        return StringUtils.isNotEmpty(item);
    }

    /**
     * Returns present working directory
     * @return dir path
     */
    public static String getCurrentDir () {
        return System.getProperty("user.dir");
    }
}
