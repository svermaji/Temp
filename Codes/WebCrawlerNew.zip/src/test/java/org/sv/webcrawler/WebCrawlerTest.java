package org.sv.webcrawler;

import org.junit.Test;

public class WebCrawlerTest {

    @Test
    public void test () {
        System.out.println("web test");

    }

}