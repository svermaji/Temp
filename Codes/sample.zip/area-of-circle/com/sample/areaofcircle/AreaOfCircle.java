package com.sample.areaofcircle;

/**
 * This class calculates area of circle
 */
public class AreaOfCircle {

    public static final double PI = Math.PI;
    private double radius;

    public static void main(String[] args) {
        AreaOfCircle areaOfCircle = new AreaOfCircle();
        areaOfCircle.calculateArea(args);
    }

    public void calculateArea(String[] args) {
        validate(args);
        printInfo(String.format("Area of circle for radius %.2f is %.2f", radius, (PI * radius)));
    }

    private void validate(String[] args) {
        validateArguments(args);
        validateFormat(args[0]);
        validateRange(radius);
    }

    private void validateArguments(String[] args) {
        // we need only one param which is circle radius
        if (args == null || args.length == 0) {
            printError("No argument passed.  Radius is required.");
        } else if (args.length > 1) {
            printError("Extra arguments passed.  Need only one argument");
        }
    }

    private void validateFormat(String arg) {
        // converting argument to double
        try {
            radius = Double.parseDouble(arg);
        } catch (NumberFormatException e) {
            printError(String.format("Invalid value %s. Only numeric value is allowed", arg));
        }
    }

    private void validateRange(double radis) {
        if (radis < 0.0 || radis > 5000.00) {
            printError(String.format("Invalid value %.2f. Radius range: [0.00 - 5000.00]", radis));
        }
    }

    private void printError(String msg) {
        printUsage();
        print(msg, "ERROR");
        throw new AreaOfCircleException(msg);
    }

    private void printUsage() {
        print("========= USAGE =========", "INFO");
        print("AreaOfCircle 12.56", "INFO");
        print("AreaOfCircle 5", "INFO");
        print("Only two digits after decimal will be considered.", "INFO");
        print("-------------------------", "INFO");
    }

    private void printInfo(String msg) {
        print(msg, "INFO");
    }

    private void print(String msg, String type) {
        System.out.println(type + ": " + msg);
    }


}