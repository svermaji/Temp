package com.sample.areaofcircle;

public class AreaOfCircleException extends RuntimeException {

    public AreaOfCircleException(String msg) {
        super(msg);
    }

}