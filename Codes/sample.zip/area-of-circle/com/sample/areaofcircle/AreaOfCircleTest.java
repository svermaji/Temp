package com.sample.areaofcircle;


import org.junit.Before;
import org.junit.Test;

public class AreaOfCircleTest {

    private AreaOfCircle areaOfCircle;

    @Before
    public void init () {
        areaOfCircle = new AreaOfCircle();
    }

    @Test
    public void testCalculate () {
        String [] args = new String[1];
        args[0] = "121.11";
        areaOfCircle.calculateArea(args);
    }

    @Test(expected = AreaOfCircleException.class)
    public void testValidateArgument () {
        String [] args = null;
        areaOfCircle.calculateArea(args);
    }

    @Test(expected = AreaOfCircleException.class)
    public void testValidateArgumentMoreThan1 () {
        String [] args = new String[2];
        args[0] = "121.11";
        args[1] = "122.11";
        areaOfCircle.calculateArea(args);
    }

    @Test(expected = AreaOfCircleException.class)
    public void testValidateFormat () {
        String [] args = new String[1];
        args[0] = "invalid-val";
        areaOfCircle.calculateArea(args);
    }

    @Test(expected = AreaOfCircleException.class)
    public void testValidateNegativeRange () {
        String [] args = new String[1];
        args[0] = "-1";
        areaOfCircle.calculateArea(args);
    }

    @Test(expected = AreaOfCircleException.class)
    public void testValidateRange () {
        String [] args = new String[1];
        args[0] = "5001";
        areaOfCircle.calculateArea(args);
    }
}