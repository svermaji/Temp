Compile
    - javac -d classes -cp ./lib/junit-4.13.jar;./lib/hamcrest-all-1.3.jar; com/sample/areaofcircle/*.java

Run
    - java -cp ./lib/*.jar;classes com.sample.areaofcircle.AreaOfCircle 2

Test
    - java -cp ./lib/junit-4.13.jar;./lib/hamcrest-all-1.3.jar;classes org.junit.runner.JUnitCore com.sample.areaofcircle.AreaOfCircleTest

