package com.sample.handlestring;

/**
 * This class takes input as string and returns first non-repeating character as result.
 * Case in-sensitive
 */
public class HandleString {

    private String str;
    private static final int MAX_CHARS = 100;

    public static void main(String[] args) {
        HandleString handleString = new HandleString();
        handleString.findFirstOccurrence(args);
    }

    public void findFirstOccurrence(String[] args) {
        validate(args);
        Character ch = getFirstNonRepeatingChar(str);
        if (ch == null) {
            printError(String.format("None of the non repeating character found in string %s", str));
        }
        printInfo(String.format("Result: '%c' is first non repeating character found in string %s", ch, str));
    }

    private Character getFirstNonRepeatingChar(String str) {
        str = str.toLowerCase();
        char[] charArr = str.toCharArray();
        int idx = 1;
        for (char ch : charArr) {
            boolean find = false;
            for (int i = idx; i < charArr.length; i++) {
                if (ch == str.charAt(i)) {
                    find = true;
                    break;
                }
            }
            idx++;
            if (!find) {
                return ch;
            }
        }

        return null;
    }

    private void validate(String[] args) {
        validateArguments(args);
        validateLimit(args[0]);
    }

    private void validateArguments(String[] args) {
        // we need only one param which is circle radius
        if (args == null || args.length == 0) {
            printError("No argument passed.  String is required.");
        } else if (args.length > 1) {
            printError("Extra arguments passed.  Need only one argument");
        }
    }

    private void validateLimit(String arg) {
        str = arg;
        if (str.length() > MAX_CHARS) {
            printError(String.format("Very long string. String length should not be more than %d.", MAX_CHARS));
        }
    }

    private void printError(String msg) {
        printUsage();
        print(msg, "ERROR");
        throw new HandleStringException(msg);
    }

    private void printUsage() {
        print("========= USAGE =========", "INFO");
        print("HandleString ThisIsString", "INFO");
        print("-------------------------", "INFO");
    }

    private void printInfo(String msg) {
        print(msg, "INFO");
    }

    private void print(String msg, String type) {
        System.out.println(type + ": " + msg);
    }
}