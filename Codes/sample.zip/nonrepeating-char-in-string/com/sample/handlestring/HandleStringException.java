package com.sample.handlestring;

public class HandleStringException extends RuntimeException {

    public HandleStringException(String msg) {
        super(msg);
    }

}