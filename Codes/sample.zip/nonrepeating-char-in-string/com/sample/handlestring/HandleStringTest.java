package com.sample.handlestring;


import org.junit.Before;
import org.junit.Test;

public class HandleStringTest {

    private HandleString handleString;

    @Before
    public void init () {
        handleString = new HandleString();
    }

    @Test
    public void testCalculate () {
        String [] args = new String[1];
        args[0] = "121.11";
        handleString.findFirstOccurrence(args);
    }

    @Test(expected = HandleStringException.class)
    public void testValidateArgument () {
        String [] args = null;
        handleString.findFirstOccurrence(args);
    }

    @Test(expected = HandleStringException.class)
    public void testValidateArgumentMoreThan1 () {
        String [] args = new String[2];
        args[0] = "abcd";
        args[1] = "abcd";
        handleString.findFirstOccurrence(args);
    }

    @Test(expected = HandleStringException.class)
    public void testLimit () {
        String [] args = new String[1];
        StringBuilder longStrB = new StringBuilder();
        for (int i=0; i < 102; i++) {
            longStrB.append("x");
        }
        args[0] = longStrB.toString();
        handleString.findFirstOccurrence(args);
    }
}