Compile
    - javac -d classes -cp ./lib/junit-4.13.jar;./lib/hamcrest-all-1.3.jar; com/sample/handlestring/*.java

Run
    - java -cp ./lib/*.jar;classes com.sample.handlestring.HandleString ThisIsString

Test
    - java -cp ./lib/junit-4.13.jar;./lib/hamcrest-all-1.3.jar;classes org.junit.runner.JUnitCore com.sample.handlestring.HandleStringTest

