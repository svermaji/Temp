package org.sv.webcrawler;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.sv.webcrawler.util.Utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * This class will help in downloading bunch of urls that
 * may point to resource like images, pdfs etc.
 */
public class DocDownLoader {

    private Logger logger;
    private boolean debug;

    public DocDownLoader() {
        logger = LoggerFactory.getLogger(this.getClass());
        debug = logger.isDebugEnabled();
    }


    /**
     *
     * @param url - File url
     * @return html Document
     */
    public Document getDocumentFromPath (String url, String domain) {

        Document doc = null;
        File input = new File(Utils.getCurrentDir()+url);

        try {
            doc = Jsoup.parse(input, Utils.UTF8_ENCODING, domain);
        } catch (IOException e) {
            logger.error("Error in downloading.  Details: "+e.getMessage());
        }

        return doc;

    }

    /**
     * Downloads http url and send data as string
     *
     * @param url to download
     * @return html document
     */
    public Document download(String url) {

        if (debug) {
            logger.debug("Trying url [" + url + "]");
        }

        long startTime = System.currentTimeMillis();
        try {
            Document doc = Jsoup.connect(url).get();

            long diffTime = (System.currentTimeMillis() - startTime);
            long diffTimeInSec = diffTime / 1000;

            if (debug) {
                logger.debug("Download completed in ["
                    + diffTimeInSec + "] seconds.");
            }
            if (debug) {
                logger.debug("File downloaded");
            }
            return doc;
        } catch (Exception e) {
            logger.error("Error in downloading.  Details: "+e.getMessage());
        }
        return null;
    }

    public Elements getHrefLinks(Document doc) {
        return doc.select("a[href]");
    }

    public List<String> makeAbsHrefLinks(Elements elements) {
        List<String> list = new ArrayList<>();
        elements.forEach(element -> list.add(element.attr("abs:href")));
        return list;
    }

    public Elements getSrcLinks(Document doc) {
        return doc.select("[src]");
    }

    public Elements getLinks(Document doc) {
        return doc.select("link[href]");
    }

}
