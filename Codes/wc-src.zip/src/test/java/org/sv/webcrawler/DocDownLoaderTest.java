package org.sv.webcrawler;

import org.junit.Test;

public class DocDownLoaderTest {

    @Test
    public void test () {
        System.out.println("res test");

    }

}

