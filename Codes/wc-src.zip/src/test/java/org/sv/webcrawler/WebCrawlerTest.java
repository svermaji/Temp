package org.sv.webcrawler;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.sv.webcrawler.helper.LinkCollector;
import org.sv.webcrawler.util.Utils;

import java.io.File;
import java.io.IOException;
import java.util.List;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class WebCrawlerTest {

    private Logger logger;

    @Mock
    private LinkCollector linkCollector;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testStartCrawling () {
        WebCrawler webCrawler = new WebCrawler();
        webCrawler.setDomain(Utils.W3SCHOOLS_SITE);
        webCrawler.setLinkCollector(linkCollector);

        when (linkCollector.getPageLinks(anyString())).thenReturn(readFile(webCrawler));

        webCrawler.startCrawling();
    }

    private List<String> readFile (WebCrawler webCrawler) {

        DocDownLoader docDownLoader = new DocDownLoader();
        Document doc = docDownLoader.getDocumentFromPath("/src/main/resource/w3schools.html",
            webCrawler.getDomain());

        if (doc == null) {
            return null;
        }

        return docDownLoader.makeAbsHrefLinks(docDownLoader.getHrefLinks(doc));
    }

}