package org.sv.webcrawler;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.sv.webcrawler.util.MyLogger;

import java.util.Arrays;
import java.util.Collection;

@RunWith(value = Parameterized.class)
public class ResourceDownLoaderTest {

    private MyLogger logger;

    @Parameterized.Parameters
    public static Collection data() {
        Object[][] data = new Object[][] { { MyLogger.createLogger(ResourceDownLoaderTest.class.getSimpleName()) } };
        return Arrays.asList(data);
    }

    public ResourceDownLoaderTest(MyLogger logger) {
        this.logger = logger;
    }

    @Test
    public void test () {
        System.out.println("res test");

    }

}

