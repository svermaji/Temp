package org.sv.webcrawler.util;

import org.junit.Test;

public class MyLoggerTest {

    @Test
    public void test () {
        System.out.println("logger test");

    }

}
