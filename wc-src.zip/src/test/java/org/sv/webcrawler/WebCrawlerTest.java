package org.sv.webcrawler;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.sv.webcrawler.helper.LinkCollector;
import org.sv.webcrawler.util.Utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class WebCrawlerTest {

    @Mock
    private LinkCollector linkCollector;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void test () {
        WebCrawler webCrawler = new WebCrawler();
        webCrawler.setLinkCollector(linkCollector);

        when (linkCollector.getPageLinks(anyString())).thenReturn(readFile(webCrawler));

        webCrawler.startCrawling();
    }

    private List<String> readFile (WebCrawler webCrawler) {
        File input = new File(Utils.getCurrentDir()+"/src/main/resource/w3schools.html");

        Document doc = null;

        try {
            doc = Jsoup.parse(input, "UTF-8", webCrawler.getDomain());
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (doc == null)
            return null;

        Elements elements = doc.select("a[href]");
        List<String> list = new ArrayList<>();
        elements.forEach(element -> list.add(element.attr("abs:href")));
        return list;
    }

}